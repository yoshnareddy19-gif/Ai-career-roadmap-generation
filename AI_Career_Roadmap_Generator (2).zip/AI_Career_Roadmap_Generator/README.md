# 🚀 AI Career Roadmap Generator

A beginner-friendly Streamlit project that recommends a career and generates a structured 90-day learning roadmap.

## Features
- Student profile form
- Career recommendation based on interests, subject and work preference
- Career descriptions
- Skills to learn
- Learning resources/topics
- Career opportunities
- 90-day roadmap
- Project ideas
- Final checklist
- Downloadable roadmap
- Modern responsive UI

## Run on Windows

1. Extract this ZIP.
2. Open the project folder in VS Code.
3. Open Terminal.
4. Create a virtual environment:

```bash
py -m venv venv
```

5. Activate it:

```bash
venv\Scripts\activate
```

6. Install requirements:

```bash
py -m pip install -r requirements.txt
```

7. Run the application:

```bash
streamlit run app.py
```

8. Open the local URL shown in the terminal, usually:
http://localhost:8501

## Project Structure

AI_Career_Roadmap_Generator/
├── app.py
├── requirements.txt
├── README.md
└── data/
    └── careers.json

## Future AI Upgrade
You can later connect Gemini/OpenAI to generate dynamic roadmaps instead of using the built-in career dataset.
