import streamlit as st
import json
from pathlib import Path

st.set_page_config(
    page_title="CareerAI Roadmap Generator",
    page_icon="🚀",
    layout="wide",
    initial_sidebar_state="expanded"
)

# ---------- Data ----------
DATA_FILE = Path(__file__).parent / "data" / "careers.json"
with open(DATA_FILE, encoding="utf-8") as f:
    careers = json.load(f)

# ---------- Styling ----------
st.markdown("""
<style>
.stApp {
    background: linear-gradient(135deg, #eef2ff 0%, #ffffff 48%, #f5f3ff 100%);
}
.hero {
    padding: 34px;
    border-radius: 24px;
    background: linear-gradient(120deg, #4f46e5, #7c3aed);
    color: white;
    margin-bottom: 25px;
    box-shadow: 0 12px 35px rgba(79,70,229,.20);
}
.hero h1 { font-size: 42px; margin-bottom: 8px; }
.hero p { font-size: 18px; opacity: .92; }
.card {
    padding: 22px;
    border-radius: 18px;
    background: rgba(255,255,255,.88);
    border: 1px solid #e5e7eb;
    box-shadow: 0 8px 25px rgba(15,23,42,.06);
    margin-bottom: 16px;
}
.badge {
    display:inline-block;
    padding:6px 12px;
    border-radius:999px;
    background:#ede9fe;
    color:#5b21b6;
    font-weight:600;
    margin:3px;
}
.step {
    padding: 16px;
    border-left: 5px solid #6366f1;
    background:#f8fafc;
    border-radius: 10px;
    margin: 10px 0;
}
.small { color:#64748b; font-size:14px; }
</style>
""", unsafe_allow_html=True)

# ---------- Helpers ----------
def recommend_career(interest, favorite_subject, goal, preferred_work):
    scores = {}
    for name, info in careers.items():
        score = 0
        tags = " ".join(info["tags"]).lower()
        text = f"{interest} {favorite_subject} {goal} {preferred_work}".lower()
        for tag in info["tags"]:
            if tag.lower() in text:
                score += 3
        if favorite_subject in info["subjects"]:
            score += 2
        scores[name] = score
    return max(scores, key=scores.get)

def roadmap(career):
    return careers[career]

# ---------- Header ----------
st.markdown("""
<div class="hero">
    <h1>🚀 CareerAI Roadmap Generator</h1>
    <p>Discover a career path and get a personalized learning roadmap based on your interests, subjects and goals.</p>
</div>
""", unsafe_allow_html=True)

# ---------- Sidebar ----------
with st.sidebar:
    st.header("👩‍🎓 Student Profile")
    name = st.text_input("Your Name", placeholder="Enter your name")
    current_level = st.selectbox(
        "Current Level",
        ["After 10th", "After 12th", "1st Year B.Tech", "2nd Year B.Tech",
         "3rd Year B.Tech", "4th Year B.Tech", "Graduate"]
    )
    marks = st.number_input("10th / Previous Percentage", 0.0, 100.0, 75.0, 0.5)
    favorite_subject = st.selectbox(
        "Favorite Subject",
        ["Mathematics", "Computer Science", "Science", "Biology", "Commerce", "English"]
    )
    interest = st.text_input(
        "Main Interest",
        placeholder="e.g. coding, AI, business, design"
    )
    goal = st.text_input(
        "Career Goal",
        placeholder="e.g. software engineer, data scientist"
    )
    preferred_work = st.selectbox(
        "What kind of work do you prefer?",
        ["Coding & Technology", "Data & Analysis", "Research & AI",
         "Business & Management", "Design & Creativity", "Helping People"]
    )

    generate = st.button("✨ Generate My Roadmap", use_container_width=True)

# ---------- Main ----------
if generate:
    if not name.strip():
        name = "Student"

    recommended = recommend_career(
        interest, favorite_subject, goal, preferred_work
    )
    selected = st.selectbox(
        "Recommended career (you can change it)",
        list(careers.keys()),
        index=list(careers.keys()).index(recommended)
    )
    info = roadmap(selected)

    st.success(f"🎯 Hello {name}! Your recommended career is **{selected}**.")

    c1, c2, c3, c4 = st.columns(4)
    c1.metric("Career Match", selected)
    c2.metric("Roadmap", "90 Days")
    c3.metric("Core Skills", len(info["skills"]))
    c4.metric("Projects", len(info["projects"]))

    st.markdown("## 🧭 Your Career Roadmap")

    col1, col2 = st.columns(2)

    with col1:
        st.markdown('<div class="card"><h3>💡 Why this career?</h3>', unsafe_allow_html=True)
        st.write(info["description"])
        st.markdown("</div>", unsafe_allow_html=True)

        st.markdown('<div class="card"><h3>🛠️ Skills to Learn</h3>', unsafe_allow_html=True)
        for skill in info["skills"]:
            st.markdown(f'<span class="badge">{skill}</span>', unsafe_allow_html=True)
        st.markdown("</div>", unsafe_allow_html=True)

    with col2:
        st.markdown('<div class="card"><h3>📚 Recommended Learning</h3>', unsafe_allow_html=True)
        for item in info["learning"]:
            st.markdown(f"• {item}")
        st.markdown("</div>", unsafe_allow_html=True)

        st.markdown('<div class="card"><h3>💼 Career Opportunities</h3>', unsafe_allow_html=True)
        for job in info["jobs"]:
            st.markdown(f"• {job}")
        st.markdown("</div>", unsafe_allow_html=True)

    st.markdown("## 📅 90-Day Learning Plan")
    tabs = st.tabs(["Days 1–30", "Days 31–60", "Days 61–90"])

    for tab, phase in zip(tabs, ["30", "60", "90"]):
        with tab:
            for week in info["plan"][phase]:
                st.markdown(
                    f'<div class="step"><b>{week["week"]}</b><br>{week["task"]}'
                    f'<br><span class="small">Outcome: {week["outcome"]}</span></div>',
                    unsafe_allow_html=True
                )

    st.markdown("## 🧪 Project Ideas")
    for i, project in enumerate(info["projects"], 1):
        st.markdown(f"**{i}. {project}**")

    st.markdown("## 🏆 Final Checklist")
    for item in info["checklist"]:
        st.checkbox(item, key=f"{selected}_{item}")

    roadmap_text = f"""
CAREERAI ROADMAP
Student: {name}
Current Level: {current_level}
Previous Percentage: {marks}%
Recommended Career: {selected}

Skills:
{chr(10).join("- " + x for x in info["skills"])}

Learning:
{chr(10).join("- " + x for x in info["learning"])}

Projects:
{chr(10).join("- " + x for x in info["projects"])}

Jobs:
{chr(10).join("- " + x for x in info["jobs"])}
"""
    st.download_button(
        "⬇️ Download Roadmap",
        roadmap_text,
        file_name=f"{selected.replace(' ', '_')}_roadmap.txt",
        mime="text/plain"
    )
else:
    st.markdown("""
    <div class="card">
    <h2>🌟 How it works</h2>
    <p>1️⃣ Enter your academic profile<br>
    2️⃣ Tell us your interests and career goal<br>
    3️⃣ Click <b>Generate My Roadmap</b><br>
    4️⃣ Get your skills, learning path, projects and 90-day plan</p>
    </div>
    """, unsafe_allow_html=True)

    st.info("💡 Tip: For a stronger recommendation, enter interests such as Python, AI, data, web development, business, design, or cybersecurity.")
